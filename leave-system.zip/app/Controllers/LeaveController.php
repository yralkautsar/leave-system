<?php

require_once __DIR__ . '/../Services/Database.php';

class LeaveController
{
    /* ==========================================================
       AUTH HELPERS
    ========================================================== */

    private static function authorizeLogin()
    {
        if (!isset($_SESSION['user'])) {
            header("Location: /login");
            exit;
        }
    }

    private static function authorizeAdmin()
    {
        if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin_approver') {
            http_response_code(403);
            header("Location: /dashboard");
            exit;
        }
    }

    /* ==========================================================
       LEAVE – EMPLOYEE
    ========================================================== */

    public static function create()
    {
        self::authorizeLogin();
        $db     = Database::connect();
        $userId = (int)$_SESSION['user']['id'];

        // Month from query string — default to current month
        $month      = preg_match('/^\d{4}-\d{2}$/', $_GET['month'] ?? '') ? $_GET['month'] : date('Y-m');
        $monthStart = $month . '-01';
        $monthEnd   = date('Y-m-t', strtotime($monthStart));

        // Holidays for the month — filtered by user's religion
        // (holidays with no religion rows apply to all)
        $userReligion = $_SESSION['user']['religion'] ?? null;

        $stmt = $db->prepare("
            SELECT holiday_date AS date, name
            FROM holidays
            WHERE holiday_date BETWEEN :s AND :e
            AND (
                NOT EXISTS (
                    SELECT 1 FROM holiday_religions hr
                    WHERE hr.holiday_id = holidays.id
                )
                OR EXISTS (
                    SELECT 1 FROM holiday_religions hr
                    WHERE hr.holiday_id = holidays.id
                    AND hr.religion     = :religion
                )
            )
        ");
        $stmt->execute([
            's'        => $monthStart,
            'e'        => $monthEnd,
            'religion' => $userReligion ?? '',
        ]);
        $holidays = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Employee's own pending + approved leaves overlapping this month
        $stmt = $db->prepare("
            SELECT lr.start_date, lr.end_date, lr.status, lt.name AS leave_type
            FROM leave_requests lr
            JOIN leave_types lt ON lr.leave_type_id = lt.id
            WHERE lr.employee_id = :id
            AND   lr.status IN ('pending', 'approved')
            AND   lr.start_date <= :e
            AND   lr.end_date   >= :s
        ");
        $stmt->execute(['id' => $userId, 's' => $monthStart, 'e' => $monthEnd]);
        $myLeaves = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Team leaves — same department, other employees, approved only
        $stmt = $db->prepare("
            SELECT lr.start_date, lr.end_date, u.name AS employee_name, lt.name AS leave_type
            FROM leave_requests lr
            JOIN users u ON lr.employee_id = u.id
            JOIN leave_types lt ON lr.leave_type_id = lt.id
            WHERE lr.employee_id != :id
            AND   lr.status = 'approved'
            AND   lr.start_date <= :e
            AND   lr.end_date   >= :s
            AND   u.department_id = (SELECT department_id FROM users WHERE id = :id2)
            AND   u.department_id IS NOT NULL
            ORDER BY lr.start_date ASC
        ");
        $stmt->execute(['id' => $userId, 'id2' => $userId, 's' => $monthStart, 'e' => $monthEnd]);
        $teamLeaves = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Employee's work schedule (weekday numbers, ISO: 1=Mon..7=Sun)
        $stmt = $db->prepare("
            SELECT wsd.weekday
            FROM work_schedule_days wsd
            JOIN users u ON u.work_schedule_id = wsd.schedule_id
            WHERE u.id = :id
        ");
        $stmt->execute(['id' => $userId]);
        $workDays = array_map('intval', $stmt->fetchAll(PDO::FETCH_COLUMN));
        if (empty($workDays)) $workDays = [1, 2, 3, 4, 5]; // fallback Mon–Fri

        // Leave types with balance — respects balance_source
        $stmt = $db->prepare("
            SELECT
                lt.id,
                lt.name,
                lt.balance_source,
                COALESCE(lb.remaining_days, 0) AS remaining_days,
                COALESCE(lb.total_days,     0) AS total_days,
                COALESCE(lb.used_days,      0) AS used_days
            FROM leave_types lt
            LEFT JOIN leave_balances lb
                ON  lb.leave_type_id  = lt.id
                AND lb.employee_id    = :id
                AND (
                    lb.leave_period_id IN (
                        SELECT id FROM leave_periods
                        WHERE start_date <= CURDATE() AND end_date >= CURDATE()
                    )
                    OR (lt.balance_source = 'admin_grant' AND lb.leave_period_id IS NULL)
                )
            ORDER BY lt.name ASC
        ");
        $stmt->execute(['id' => $userId]);
        $leaveTypesRaw = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // For comp leave, override remaining_days from comp_claims
        $compStmt = $db->prepare("
            SELECT COALESCE(SUM(days_remaining), 0)
            FROM comp_claims
            WHERE employee_id = :id
              AND status      = 'approved'
              AND expires_at  > CURDATE()
        ");
        $compStmt->execute(['id' => $userId]);
        $compAvailable = (float)$compStmt->fetchColumn();

        $leaveTypes = [];
        foreach ($leaveTypesRaw as $lt) {
            if ($lt['balance_source'] === 'comp') {
                $lt['remaining_days'] = $compAvailable;
                $lt['total_days']     = $compAvailable;
                $lt['used_days']      = 0;
            }
            $leaveTypes[] = $lt;
        }

        require __DIR__ . '/../../resources/views/leave_create.php';
    }

    public static function myData()
    {
        self::authorizeLogin();
        $db     = Database::connect();
        $userId = (int)$_SESSION['user']['id'];

        // Full profile
        $stmt = $db->prepare("
            SELECT u.*,
                   d.name AS dept_name,
                   j.name AS job_title_name
            FROM users u
            LEFT JOIN departments d ON u.department_id = d.id
            LEFT JOIN job_titles  j ON u.job_title_id  = j.id
            WHERE u.id = :id
        ");
        $stmt->execute(['id' => $userId]);
        $profile = $stmt->fetch(PDO::FETCH_ASSOC);

        // Full leave history with period name
        $stmt = $db->prepare("
            SELECT lr.*, lt.name AS leave_type,
                   COALESCE(lp.name, 'Compensate Leave') AS period_name
            FROM leave_requests lr
            JOIN leave_types   lt ON lr.leave_type_id   = lt.id
            LEFT JOIN leave_periods lp ON lr.leave_period_id = lp.id
            WHERE lr.employee_id = :id
            ORDER BY lr.created_at DESC
        ");
        $stmt->execute(['id' => $userId]);
        $history = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Current balances — ONLY period-based (Annual Leave)
        $stmt = $db->prepare("
            SELECT lt.name AS leave_type, lt.balance_source,
                   lp.name AS period_name, lp.end_date,
                   lb.total_days, lb.used_days,
                   (lb.total_days - lb.used_days) AS remaining_days
            FROM leave_balances lb
            JOIN leave_types   lt ON lb.leave_type_id   = lt.id
            JOIN leave_periods lp ON lb.leave_period_id = lp.id
            WHERE lb.employee_id    = :id
            AND   lt.balance_source = 'period'
            AND   lp.start_date    <= CURDATE()
            AND   lp.end_date      >= CURDATE()
            ORDER BY lt.name ASC
        ");
        $stmt->execute(['id' => $userId]);
        $balanceSummary = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Admin-granted balances (floating, no period)
        $grantStmt = $db->prepare("
            SELECT lt.name AS leave_type,
                   lb.total_days, lb.used_days,
                   (lb.total_days - lb.used_days) AS remaining_days
            FROM leave_balances lb
            JOIN leave_types lt ON lb.leave_type_id = lt.id
            WHERE lb.employee_id      = :id
              AND lt.balance_source   = 'admin_grant'
              AND lb.leave_period_id  IS NULL
            ORDER BY lt.name ASC
        ");
        $grantStmt->execute(['id' => $userId]);
        $grantBalances = $grantStmt->fetchAll(PDO::FETCH_ASSOC);

        // Compensate Leave balance — from comp_claims (floating, not leave_balances)
        $compStmt = $db->prepare("
            SELECT COALESCE(SUM(days_remaining), 0)
            FROM comp_claims
            WHERE employee_id = :id
              AND status      = 'approved'
              AND expires_at  > CURDATE()
        ");
        $compStmt->execute(['id' => $userId]);
        $compBalance = (float)$compStmt->fetchColumn();

        // Comp claims breakdown (approved, for expiry detail)
        $compDetailStmt = $db->prepare("
            SELECT days_earned, days_remaining, expires_at, worked_date
            FROM comp_claims
            WHERE employee_id = :id
              AND status      = 'approved'
              AND expires_at  > CURDATE()
            ORDER BY expires_at ASC
        ");
        $compDetailStmt->execute(['id' => $userId]);
        $compClaims = $compDetailStmt->fetchAll(PDO::FETCH_ASSOC);

        // Total comp used = earned - remaining (approved, not expired + expired)
        $compUsedStmt = $db->prepare("
            SELECT COALESCE(SUM(days_earned - days_remaining), 0)
            FROM comp_claims
            WHERE employee_id = :id
              AND status = 'approved'
        ");
        $compUsedStmt->execute(['id' => $userId]);
        $compUsed = (float)$compUsedStmt->fetchColumn();

        // Periods list for filter dropdown
        $periods = $db->query("SELECT id, name FROM leave_periods ORDER BY start_date DESC")
            ->fetchAll(PDO::FETCH_ASSOC);

        require __DIR__ . '/../../resources/views/my_data.php';
    }

    public static function store()
    {
        self::authorizeLogin();
        $db = Database::connect();

        $empId        = (int)$_SESSION['user']['id'];
        $leaveTypeId  = (int)($_POST['leave_type_id'] ?? 0);
        $startDate    = trim($_POST['start_date']    ?? '');
        $endDate      = trim($_POST['end_date']      ?? '');
        $durationType = $_POST['duration_type'] ?? 'full';

        // ── 1. Basic input validation ──────────────────────────────────
        if (!$leaveTypeId || !$startDate || !$endDate) {
            $_SESSION['error'] = "All fields are required.";
            header("Location: /leave");
            exit;
        }

        if ($endDate < $startDate) {
            $_SESSION['error'] = "End date cannot be before start date.";
            header("Location: /leave");
            exit;
        }

        // ── 2. Server-side total_days via LeaveCalculator ──────────────
        require_once __DIR__ . '/../Services/LeaveCalculator.php';

        try {
            $workingDays = LeaveCalculator::calculateWorkingDays($empId, $startDate, $endDate);
        } catch (Exception $e) {
            $_SESSION['error'] = "Could not calculate working days: " . $e->getMessage();
            header("Location: /leave");
            exit;
        }

        if ($workingDays <= 0) {
            $_SESSION['error'] = "The selected date range contains no working days (all weekends or public holidays).";
            header("Location: /leave");
            exit;
        }

        // Half day: halve the working days, minimum 0.5
        $totalDays = (($durationType === 'half_am' || $durationType === 'half_pm'))
            ? max(0.5, round($workingDays / 2, 1))
            : (float)$workingDays;

        // ── 3. Detect balance source ──────────────────────────────
        $ltStmt = $db->prepare("SELECT name, balance_source FROM leave_types WHERE id = :id");
        $ltStmt->execute(['id' => $leaveTypeId]);
        $ltRow         = $ltStmt->fetch(PDO::FETCH_ASSOC);
        $leaveTypeName = $ltRow ? (string)$ltRow['name'] : '';
        $balanceSource = $ltRow ? (string)$ltRow['balance_source'] : 'period';

        if ($balanceSource === 'comp') {
            // ── Comp leave: balance from comp_claims ───────────────────
            $availStmt = $db->prepare("
                SELECT COALESCE(SUM(days_remaining), 0)
                FROM comp_claims
                WHERE employee_id = :emp
                  AND status      = 'approved'
                  AND expires_at  > CURDATE()
            ");
            $availStmt->execute(['emp' => $empId]);
            $available = (float)$availStmt->fetchColumn();

            if ($available < $totalDays) {
                $_SESSION['error'] = "Insufficient compensate leave balance. You have {$available} day(s) available.";
                header("Location: /leave");
                exit;
            }
            $leavePeriodId = null;
        } elseif ($balanceSource === 'unlimited') {
            // ── Unlimited (Sick Leave): no balance check, no period ────
            $leavePeriodId = null;
        } elseif ($balanceSource === 'admin_grant') {
            // ── Admin grant: check leave_balances where period IS NULL ─
            $stmt = $db->prepare("
                SELECT id, remaining_days
                FROM leave_balances
                WHERE employee_id    = :emp
                  AND leave_type_id  = :type
                  AND leave_period_id IS NULL
                LIMIT 1
            ");
            $stmt->execute(['emp' => $empId, 'type' => $leaveTypeId]);
            $grantRow = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$grantRow || (float)$grantRow['remaining_days'] < $totalDays) {
                $available = $grantRow ? (float)$grantRow['remaining_days'] : 0;
                $_SESSION['error'] = "Insufficient {$leaveTypeName} balance. You have {$available} day(s) available.";
                header("Location: /leave");
                exit;
            }
            $leavePeriodId = null;
        } else {
            // ── Period leave (Annual Leave): find active period ────────
            $stmt = $db->prepare("
                SELECT lb.leave_period_id, lp.name AS period_name, lb.remaining_days
                FROM leave_balances lb
                JOIN leave_periods lp ON lb.leave_period_id = lp.id
                WHERE lb.employee_id   = :emp
                AND   lb.leave_type_id = :type
                AND   lp.start_date   <= :start
                AND   lp.end_date     >= :start
                ORDER BY lp.start_date ASC
                LIMIT 1
            ");
            $stmt->execute([
                'emp'   => $empId,
                'type'  => $leaveTypeId,
                'start' => $startDate,
            ]);
            $periodRow = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$periodRow) {
                $_SESSION['error'] = "No leave period found for the selected dates. Please contact HR.";
                header("Location: /leave");
                exit;
            }

            $leavePeriodId = $periodRow['leave_period_id'];
            $remaining     = (float)$periodRow['remaining_days'];

            if ($remaining < $totalDays) {
                $_SESSION['error'] = "Insufficient balance. You have {$remaining} day(s) remaining but this request requires {$totalDays} day(s).";
                header("Location: /leave");
                exit;
            }
        }

        // ── 5. Overlap check ───────────────────────────────────────────
        $stmt = $db->prepare("
            SELECT COUNT(*)
            FROM leave_requests
            WHERE employee_id = :emp
            AND   status NOT IN ('rejected', 'cancelled')
            AND   start_date <= :end
            AND   end_date   >= :start
        ");
        $stmt->execute([
            'emp'   => $empId,
            'start' => $startDate,
            'end'   => $endDate,
        ]);

        if ((int)$stmt->fetchColumn() > 0) {
            $_SESSION['error'] = "You already have a leave request that overlaps with the selected dates.";
            header("Location: /leave");
            exit;
        }

        // ── 6. Insert ──────────────────────────────────────────────────
        $stmt = $db->prepare("
            INSERT INTO leave_requests
            (employee_id, leave_type_id, leave_period_id, start_date, end_date, duration_type, total_days, reason, status, created_at)
            VALUES
            (:emp, :type, :period, :start, :end, :duration, :total, :reason, 'pending', NOW())
        ");

        $stmt->execute([
            'emp'      => $empId,
            'type'     => $leaveTypeId,
            'period'   => $leavePeriodId,
            'start'    => $startDate,
            'end'      => $endDate,
            'duration' => $durationType,
            'total'    => $totalDays,
            'reason'   => trim($_POST['reason'] ?? '') ?: null,
        ]);

        // ── 7. Email notification ──────────────────────────────────────
        try {
            require_once __DIR__ . '/../Services/MailService.php';

            $empStmt = $db->prepare("
                SELECT u.*, d.name AS department
                FROM users u
                LEFT JOIN departments d ON u.department_id = d.id
                WHERE u.id = :id
            ");
            $empStmt->execute(['id' => $empId]);
            $employee = $empStmt->fetch(PDO::FETCH_ASSOC);

            $ltStmt = $db->prepare("SELECT name FROM leave_types WHERE id = :id");
            $ltStmt->execute(['id' => $leaveTypeId]);
            $leaveTypeName = $ltStmt->fetchColumn();

            MailService::notifyLeaveSubmitted([
                'leave_type' => $leaveTypeName,
                'start_date' => $startDate,
                'end_date'   => $endDate,
                'total_days' => $totalDays,
            ], $employee);
        } catch (Exception $e) {
            // Silent — email failure must not block submission
        }

        $fmtStart = date('d M Y', strtotime($startDate));
        $fmtEnd   = date('d M Y', strtotime($endDate));
        $_SESSION['success'] = "Leave request submitted — {$fmtStart}" .
            ($startDate !== $endDate ? " to {$fmtEnd}" : '') .
            " ({$totalDays} day" . ($totalDays != 1 ? 's' : '') . "). HR has been notified.";
        header("Location: /dashboard");
        exit;
    }

    public static function myHistory()
    {
        self::authorizeLogin();
        $db = Database::connect();

        $stmt = $db->prepare("
            SELECT lr.*, lt.name AS leave_type
            FROM leave_requests lr
            JOIN leave_types lt ON lr.leave_type_id = lt.id
            WHERE lr.employee_id = :id
            ORDER BY lr.created_at DESC
        ");
        $stmt->execute(['id' => $_SESSION['user']['id']]);
        $history = $stmt->fetchAll(PDO::FETCH_ASSOC);

        require __DIR__ . '/../../resources/views/leave_history.php';
    }

    public static function cancel(int $id)
    {
        self::authorizeLogin();
        $db = Database::connect();

        $stmt = $db->prepare("
            UPDATE leave_requests
            SET status = 'cancelled'
            WHERE id = :id
            AND employee_id = :emp
            AND status = 'pending'
        ");

        $stmt->execute([
            'id'  => $id,
            'emp' => $_SESSION['user']['id']
        ]);

        header("Location: /my-data");
        exit;
    }

    /* ==========================================================
       APPROVAL (ADMIN)
    ========================================================== */

    public static function approve(int $id)
    {
        self::authorizeAdmin();
        $db = Database::connect();

        try {
            $db->beginTransaction();

            $stmt = $db->prepare("
                SELECT * FROM leave_requests
                WHERE id = :id AND status = 'pending'
                FOR UPDATE
            ");
            $stmt->execute(['id' => $id]);
            $request = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$request) {
                throw new Exception("Request not found or already processed.");
            }

            // ── Detect balance source ──────────────────────────
            $ltStmt = $db->prepare("SELECT name, balance_source FROM leave_types WHERE id = :id");
            $ltStmt->execute(['id' => $request['leave_type_id']]);
            $ltRow         = $ltStmt->fetch(PDO::FETCH_ASSOC);
            $leaveTypeName = $ltRow ? (string)$ltRow['name'] : '';
            $balanceSource = $ltRow ? (string)$ltRow['balance_source'] : 'period';

            if ($balanceSource === 'comp') {
                // ── Comp leave: deduct from comp_claims FIFO by expires_at ──
                $availStmt = $db->prepare("
                    SELECT COALESCE(SUM(days_remaining), 0)
                    FROM comp_claims
                    WHERE employee_id = :emp
                      AND status      = 'approved'
                      AND expires_at  > CURDATE()
                ");
                $availStmt->execute(['emp' => $request['employee_id']]);
                $available = (float)$availStmt->fetchColumn();

                if ($available < $request['total_days']) {
                    throw new Exception("Insufficient compensate leave balance. Available: {$available} day(s).");
                }

                $claimsStmt = $db->prepare("
                    SELECT id, days_remaining FROM comp_claims
                    WHERE employee_id = :emp
                      AND status      = 'approved'
                      AND expires_at  > CURDATE()
                    ORDER BY expires_at ASC
                    FOR UPDATE
                ");
                $claimsStmt->execute(['emp' => $request['employee_id']]);
                $claimsRows = $claimsStmt->fetchAll(PDO::FETCH_ASSOC);

                $toDeduct = (float)$request['total_days'];
                foreach ($claimsRows as $cr) {
                    if ($toDeduct <= 0) break;
                    $deduct = min($toDeduct, (float)$cr['days_remaining']);
                    $db->prepare("UPDATE comp_claims SET days_remaining = days_remaining - :d WHERE id = :id")
                        ->execute(['d' => $deduct, 'id' => $cr['id']]);
                    $toDeduct -= $deduct;
                }
            } elseif ($balanceSource === 'unlimited') {
                // ── Unlimited (Sick Leave): no deduction needed ───────────

            } elseif ($balanceSource === 'admin_grant') {
                // ── Admin grant: deduct from leave_balances (period IS NULL) ─
                $balStmt = $db->prepare("
                    SELECT id, remaining_days FROM leave_balances
                    WHERE employee_id   = :emp
                      AND leave_type_id = :type
                      AND leave_period_id IS NULL
                    LIMIT 1
                    FOR UPDATE
                ");
                $balStmt->execute([
                    'emp'  => $request['employee_id'],
                    'type' => $request['leave_type_id'],
                ]);
                $balance = $balStmt->fetch(PDO::FETCH_ASSOC);

                if (!$balance || (float)$balance['remaining_days'] < $request['total_days']) {
                    throw new Exception("Insufficient {$leaveTypeName} balance.");
                }

                $db->prepare("
                    UPDATE leave_balances
                    SET used_days      = used_days + :days,
                        remaining_days = remaining_days - :days
                    WHERE id = :id
                ")->execute(['days' => $request['total_days'], 'id' => $balance['id']]);
            } else {
                // ── Period leave (Annual): deduct from leave_balances ──────
                $stmt = $db->prepare("
                    SELECT * FROM leave_balances
                    WHERE employee_id    = :emp
                      AND leave_type_id  = :type
                      AND leave_period_id = :period
                    FOR UPDATE
                ");
                $stmt->execute([
                    'emp'    => $request['employee_id'],
                    'type'   => $request['leave_type_id'],
                    'period' => $request['leave_period_id'],
                ]);
                $balance = $stmt->fetch(PDO::FETCH_ASSOC);

                if (!$balance || $balance['remaining_days'] < $request['total_days']) {
                    throw new Exception("Insufficient leave balance.");
                }

                $db->prepare("
                    UPDATE leave_balances
                    SET used_days      = used_days + :days,
                        remaining_days = remaining_days - :days
                    WHERE id = :id
                ")->execute(['days' => $request['total_days'], 'id' => $balance['id']]);
            }

            $stmt = $db->prepare("
                UPDATE leave_requests
                SET status = 'approved',
                    approved_at = NOW(),
                    approved_by = :admin
                WHERE id = :id
            ");
            $stmt->execute([
                'id'    => $id,
                'admin' => $_SESSION['user']['id']
            ]);

            $db->commit();

            // ── Email notification ──
            try {
                require_once __DIR__ . '/../Services/MailService.php';

                $empStmt = $db->prepare("
                    SELECT u.*, d.name AS department
                    FROM users u
                    LEFT JOIN departments d ON u.department_id = d.id
                    WHERE u.id = :id
                ");
                $empStmt->execute(['id' => $request['employee_id']]);
                $employee = $empStmt->fetch(PDO::FETCH_ASSOC);

                $ltStmt = $db->prepare("SELECT name FROM leave_types WHERE id = :id");
                $ltStmt->execute(['id' => $request['leave_type_id']]);
                $leaveTypeName = $ltStmt->fetchColumn();

                $emailRequest = [
                    'leave_type' => $leaveTypeName,
                    'start_date' => $request['start_date'],
                    'end_date'   => $request['end_date'],
                    'total_days' => $request['total_days'],
                ];

                MailService::notifyLeaveApproved($emailRequest, $employee, $_SESSION['user']['name']);
            } catch (Exception $e) {
                // Silent
            }
        } catch (Exception $e) {
            $db->rollBack();
            $_SESSION['error'] = "Approval failed: " . $e->getMessage();
        }

        $redirect = ($_POST['_from'] ?? '') === 'requests'
            ? '/admin/requests'
            : '/dashboard';

        header("Location: $redirect");
        exit;
    }

    public static function reject(int $id)
    {
        self::authorizeAdmin();
        $db = Database::connect();

        $reason = trim($_POST['rejection_reason'] ?? '');

        // Fetch before update so we have employee_id and leave_type_id
        $stmt = $db->prepare("SELECT * FROM leave_requests WHERE id = :id AND status = 'pending'");
        $stmt->execute(['id' => $id]);
        $request = $stmt->fetch(PDO::FETCH_ASSOC);

        $stmt = $db->prepare("
            UPDATE leave_requests
            SET status           = 'rejected',
                approved_by      = :admin,
                approved_at      = NOW(),
                rejection_reason = :reason
            WHERE id = :id AND status = 'pending'
        ");
        $stmt->execute([
            'id'     => $id,
            'admin'  => $_SESSION['user']['id'],
            'reason' => $reason ?: null,
        ]);

        // ── Email notification ──
        if ($request) {
            try {
                require_once __DIR__ . '/../Services/MailService.php';

                $empStmt = $db->prepare("
                    SELECT u.*, d.name AS department
                    FROM users u
                    LEFT JOIN departments d ON u.department_id = d.id
                    WHERE u.id = :id
                ");
                $empStmt->execute(['id' => $request['employee_id']]);
                $employee = $empStmt->fetch(PDO::FETCH_ASSOC);

                $ltStmt = $db->prepare("SELECT name FROM leave_types WHERE id = :id");
                $ltStmt->execute(['id' => $request['leave_type_id']]);
                $leaveTypeName = $ltStmt->fetchColumn();

                $emailRequest = [
                    'leave_type'       => $leaveTypeName,
                    'start_date'       => $request['start_date'],
                    'end_date'         => $request['end_date'],
                    'total_days'       => $request['total_days'],
                    'rejection_reason' => $reason,
                ];

                MailService::notifyLeaveRejected($emailRequest, $employee, $_SESSION['user']['name']);
            } catch (Exception $e) {
                // Silent
            }
        }

        $_SESSION['success'] = "Request rejected.";

        $redirect = ($_POST['_from'] ?? '') === 'requests'
            ? '/admin/requests' . (isset($_SERVER['HTTP_REFERER']) ? '?' . parse_url($_SERVER['HTTP_REFERER'], PHP_URL_QUERY) : '')
            : '/dashboard';

        header("Location: $redirect");
        exit;
    }

    /* ==========================================================
       API – REQUEST DETAIL (JSON)
    ========================================================== */

    public static function requestDetail(int $id)
    {
        self::authorizeAdmin();
        $db = Database::connect();

        // Full request detail
        $stmt = $db->prepare("
            SELECT
                lr.id,
                lr.start_date,
                lr.end_date,
                lr.total_days,
                lr.duration_type,
                lr.status,
                lr.created_at,
                lr.approved_at,
                lr.rejection_reason,
                u.name          AS employee_name,
                u.email         AS employee_email,
                u.join_date,
                d.name          AS department,
                j.name          AS job_title,
                lt.name         AS leave_type,
                adm.name        AS processed_by,
                lp.name         AS period_name
            FROM leave_requests lr
            JOIN users u            ON lr.employee_id     = u.id
            JOIN leave_types lt     ON lr.leave_type_id   = lt.id
            LEFT JOIN departments d ON u.department_id    = d.id
            LEFT JOIN job_titles j  ON u.job_title_id     = j.id
            LEFT JOIN users adm     ON lr.approved_by     = adm.id
            LEFT JOIN leave_periods lp ON lr.leave_period_id = lp.id
            WHERE lr.id = :id
        ");
        $stmt->execute(['id' => $id]);
        $detail = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$detail) {
            http_response_code(404);
            echo json_encode(['error' => 'Not found']);
            exit;
        }

        // Current balance for this leave type
        $stmt = $db->prepare("
            SELECT
                lb.total_days,
                lb.used_days,
                lb.remaining_days
            FROM leave_balances lb
            JOIN leave_periods lp ON lb.leave_period_id = lp.id
            WHERE lb.employee_id   = (
                SELECT employee_id FROM leave_requests WHERE id = :id
            )
            AND lb.leave_type_id   = (
                SELECT leave_type_id FROM leave_requests WHERE id = :id2
            )
            AND lp.start_date <= CURDATE() AND lp.end_date >= CURDATE()
            LIMIT 1
        ");
        $stmt->execute(['id' => $id, 'id2' => $id]);
        $balance = $stmt->fetch(PDO::FETCH_ASSOC);

        $detail['balance'] = $balance ?: null;

        header('Content-Type: application/json');
        echo json_encode($detail);
        exit;
    }

    /* ==========================================================
       REVOKE — undo an approved leave (admin only)
    ========================================================== */

    public static function revoke(int $id)
    {
        self::authorizeAdmin();
        $db = Database::connect();

        try {
            $db->beginTransaction();

            // Lock the request
            $stmt = $db->prepare("
                SELECT * FROM leave_requests
                WHERE id = :id AND status = 'approved'
                FOR UPDATE
            ");
            $stmt->execute(['id' => $id]);
            $request = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$request) {
                throw new Exception("Request not found or not in approved state.");
            }

            // Restore balance
            $stmt = $db->prepare("
                UPDATE leave_balances
                SET used_days      = used_days      - :days,
                    remaining_days = remaining_days + :days
                WHERE employee_id     = :emp
                AND   leave_period_id = :period
            ");
            $stmt->execute([
                'days'   => $request['total_days'],
                'emp'    => $request['employee_id'],
                'period' => $request['leave_period_id'],
            ]);

            // Set back to pending
            $stmt = $db->prepare("
                UPDATE leave_requests
                SET status      = 'pending',
                    approved_at = NULL,
                    approved_by = NULL
                WHERE id = :id
            ");
            $stmt->execute(['id' => $id]);

            $db->commit();

            $_SESSION['success'] = "Leave request has been revoked and returned to pending.";
        } catch (Exception $e) {
            $db->rollBack();
            $_SESSION['error'] = "Revoke failed: " . $e->getMessage();
        }

        $qs = $_POST['_qs'] ?? '';
        header("Location: /admin/requests" . ($qs ? '?' . $qs : ''));
        exit;
    }

    public static function departments()
    {
        self::authorizeAdmin();
        $db = Database::connect();

        $departments = $db->query("
            SELECT d.*, COUNT(u.id) AS user_count
            FROM departments d
            LEFT JOIN users u ON u.department_id = d.id AND u.is_active = 1
            GROUP BY d.id
            ORDER BY d.name ASC
        ")->fetchAll(PDO::FETCH_ASSOC);

        require __DIR__ . '/../../resources/views/admin_departments.php';
    }

    public static function storeDepartment()
    {
        self::authorizeAdmin();
        $db = Database::connect();

        $name = trim($_POST['name'] ?? '');
        if (!$name) {
            $_SESSION['error'] = "Department name cannot be empty.";
            header("Location: /admin/departments");
            exit;
        }

        // Check duplicate
        $check = $db->prepare("SELECT id FROM departments WHERE name = :name LIMIT 1");
        $check->execute(['name' => $name]);
        if ($check->fetch()) {
            $_SESSION['error'] = "Department \"{$name}\" already exists.";
            header("Location: /admin/departments");
            exit;
        }

        $stmt = $db->prepare("INSERT INTO departments (name) VALUES (:name)");
        $stmt->execute(['name' => $name]);
        $_SESSION['success'] = "Department \"{$name}\" added.";

        header("Location: /admin/departments");
        exit;
    }

    public static function updateDepartment(int $id)
    {
        self::authorizeAdmin();
        $db = Database::connect();

        $name = trim($_POST['name'] ?? '');
        if (!$name) {
            $_SESSION['error'] = "Name cannot be empty.";
            header("Location: /admin/departments");
            exit;
        }

        $stmt = $db->prepare("UPDATE departments SET name = :name WHERE id = :id");
        $stmt->execute(['name' => $name, 'id' => $id]);
        $_SESSION['success'] = "Department updated.";

        header("Location: /admin/departments");
        exit;
    }

    public static function deleteDepartment(int $id)
    {
        self::authorizeAdmin();
        $db = Database::connect();

        // Block delete if users are assigned
        $check = $db->prepare("SELECT COUNT(*) FROM users WHERE department_id = :id");
        $check->execute(['id' => $id]);
        if ((int)$check->fetchColumn() > 0) {
            $_SESSION['error'] = "Cannot delete — there are employees assigned to this department.";
            header("Location: /admin/departments");
            exit;
        }

        $stmt = $db->prepare("DELETE FROM departments WHERE id = :id");
        $stmt->execute(['id' => $id]);
        $_SESSION['success'] = "Department deleted.";

        header("Location: /admin/departments");
        exit;
    }

    /* ==========================================================
       ADMIN – JOB TITLES
    ========================================================== */

    public static function jobTitles()
    {
        self::authorizeAdmin();
        $db = Database::connect();

        $jobTitles = $db->query("
            SELECT j.*, COUNT(u.id) AS user_count
            FROM job_titles j
            LEFT JOIN users u ON u.job_title_id = j.id AND u.is_active = 1
            GROUP BY j.id
            ORDER BY j.name ASC
        ")->fetchAll(PDO::FETCH_ASSOC);

        require __DIR__ . '/../../resources/views/admin_jobtitles.php';
    }

    public static function storeJobTitle()
    {
        self::authorizeAdmin();
        $db = Database::connect();

        $name = trim($_POST['name'] ?? '');
        if (!$name) {
            $_SESSION['error'] = "Job title name cannot be empty.";
            header("Location: /admin/job-titles");
            exit;
        }

        $check = $db->prepare("SELECT id FROM job_titles WHERE name = :name LIMIT 1");
        $check->execute(['name' => $name]);
        if ($check->fetch()) {
            $_SESSION['error'] = "Job title \"{$name}\" already exists.";
            header("Location: /admin/job-titles");
            exit;
        }

        $stmt = $db->prepare("INSERT INTO job_titles (name) VALUES (:name)");
        $stmt->execute(['name' => $name]);
        $_SESSION['success'] = "Job title \"{$name}\" added.";

        header("Location: /admin/job-titles");
        exit;
    }

    public static function updateJobTitle(int $id)
    {
        self::authorizeAdmin();
        $db = Database::connect();

        $name = trim($_POST['name'] ?? '');
        if (!$name) {
            $_SESSION['error'] = "Name cannot be empty.";
            header("Location: /admin/job-titles");
            exit;
        }

        $stmt = $db->prepare("UPDATE job_titles SET name = :name WHERE id = :id");
        $stmt->execute(['name' => $name, 'id' => $id]);
        $_SESSION['success'] = "Job title updated.";

        header("Location: /admin/job-titles");
        exit;
    }

    public static function deleteJobTitle(int $id)
    {
        self::authorizeAdmin();
        $db = Database::connect();

        $check = $db->prepare("SELECT COUNT(*) FROM users WHERE job_title_id = :id");
        $check->execute(['id' => $id]);
        if ((int)$check->fetchColumn() > 0) {
            $_SESSION['error'] = "Cannot delete — there are employees with this job title.";
            header("Location: /admin/job-titles");
            exit;
        }

        $stmt = $db->prepare("DELETE FROM job_titles WHERE id = :id");
        $stmt->execute(['id' => $id]);
        $_SESSION['success'] = "Job title deleted.";

        header("Location: /admin/job-titles");
        exit;
    }

    /* ==========================================================
       ADMIN – USERS
    ========================================================== */

    public static function users()
    {
        self::authorizeAdmin();
        $db = Database::connect();

        $departments   = $db->query("SELECT * FROM departments ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);
        $jobTitles     = $db->query("SELECT * FROM job_titles ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);
        $workSchedules = $db->query("SELECT * FROM work_schedules")->fetchAll(PDO::FETCH_ASSOC);

        // All active users as candidates for HoD / GM selection
        $allUsers = $db->query("
            SELECT id, name, email, role FROM users
            WHERE is_active = 1
            ORDER BY name ASC
        ")->fetchAll(PDO::FETCH_ASSOC);

        // ── Filters ──
        $search     = trim($_GET['search'] ?? '');
        $roleFilter = $_GET['role']   ?? '';
        $deptFilter = $_GET['dept']   ?? '';
        $statusFilter = $_GET['status'] ?? '';

        $query = "
            SELECT
                u.*,
                d.name  AS department,
                j.name  AS job_title,
                hod.name  AS hod_name,
                hod.email AS hod_email,
                gm.name   AS gm_name,
                gm.email  AS gm_email
            FROM users u
            LEFT JOIN departments d  ON u.department_id = d.id
            LEFT JOIN job_titles j   ON u.job_title_id  = j.id
            LEFT JOIN users hod      ON u.hod_id        = hod.id
            LEFT JOIN users gm       ON u.gm_id         = gm.id
            WHERE 1=1
        ";

        $params = [];

        if ($search) {
            $query .= " AND (u.name LIKE :search OR u.email LIKE :search2)";
            $params['search']  = "%$search%";
            $params['search2'] = "%$search%";
        }
        if ($roleFilter) {
            $query .= " AND u.role = :role";
            $params['role'] = $roleFilter;
        }
        if ($deptFilter) {
            $query .= " AND u.department_id = :dept";
            $params['dept'] = $deptFilter;
        }
        if ($statusFilter === 'active') {
            $query .= " AND u.is_active = 1";
        } elseif ($statusFilter === 'suspended') {
            $query .= " AND u.is_active = 0";
        }

        $query .= " ORDER BY u.name ASC";

        $stmt = $db->prepare($query);
        $stmt->execute($params);
        $users = $stmt->fetchAll(PDO::FETCH_ASSOC);

        require __DIR__ . '/../../resources/views/admin_users.php';
    }

    public static function storeUser()
    {
        self::authorizeAdmin();
        $db = Database::connect();

        $email = trim($_POST['email'] ?? '');

        // Duplicate email check
        $check = $db->prepare("SELECT id FROM users WHERE email = :email LIMIT 1");
        $check->execute(['email' => $email]);
        if ($check->fetch()) {
            $_SESSION['error'] = "Email \"{$email}\" is already registered.";
            header("Location: /admin/users");
            exit;
        }

        $stmt = $db->prepare("
            INSERT INTO users
            (name, nickname, religion, email, password_hash, role,
             department_id, job_title_id,
             hod_id, gm_id,
             join_date, is_active, created_at)
            VALUES
            (:name, :nickname, :religion, :email, :pass, :role,
             :dept, :job,
             :hod, :gm,
             :join, 1, NOW())
        ");

        $stmt->execute([
            'name'     => trim($_POST['name']),
            'nickname' => trim($_POST['nickname'] ?? '') ?: null,
            'religion' => trim($_POST['religion']  ?? '') ?: null,
            'email'    => $email,
            'pass'     => password_hash($_POST['password'], PASSWORD_DEFAULT),
            'role'     => $_POST['role'],
            'dept'     => $_POST['department_id'] ?: null,
            'job'      => $_POST['job_title_id']  ?: null,
            'hod'      => $_POST['hod_id']        ?: null,
            'gm'       => $_POST['gm_id']         ?: null,
            'join'     => $_POST['join_date'],
        ]);

        $newUserId  = (int)$db->lastInsertId();
        $newJoin    = $_POST['join_date'];

        // ── Auto-generate leave balances for all currently active periods ──
        try {
            $leaveTypes = $db->query("SELECT * FROM leave_types WHERE balance_source = 'period' AND default_days > 0")
                ->fetchAll(PDO::FETCH_ASSOC);

            $activePeriodsStmt = $db->prepare("
                SELECT * FROM leave_periods
                WHERE start_date <= CURDATE() AND end_date >= CURDATE()
            ");
            $activePeriodsStmt->execute();
            $activePeriods = $activePeriodsStmt->fetchAll(PDO::FETCH_ASSOC);

            $balancesCreated = 0;

            foreach ($activePeriods as $period) {
                foreach ($leaveTypes as $type) {
                    $db->prepare("
                        INSERT IGNORE INTO leave_balances
                        (employee_id, leave_period_id, leave_type_id, total_days, remaining_days, used_days)
                        VALUES (:emp, :period, :type, :days, :days, 0)
                    ")->execute([
                        'emp'    => $newUserId,
                        'period' => $period['id'],
                        'type'   => $type['id'],
                        'days'   => $type['default_days'],
                    ]);
                    $balancesCreated++;
                }
            }

            $msg = "User " . htmlspecialchars(trim($_POST['name'])) . " added.";
            if ($balancesCreated > 0) {
                $msg .= " {$balancesCreated} leave balance(s) generated for active period(s).";
            }
            $_SESSION['success'] = $msg;
        } catch (Exception $e) {
            // Balance generation failure must not block user creation
            $_SESSION['success'] = "User " . htmlspecialchars(trim($_POST['name'])) . " added.";
            $_SESSION['warning'] = "Balance auto-generation failed: " . $e->getMessage();
        }

        header("Location: /admin/users");
        exit;
    }

    public static function updateUser(int $id)
    {
        self::authorizeAdmin();
        $db = Database::connect();

        // Email uniqueness check (excluding self)
        $email = trim($_POST['email'] ?? '');
        $check = $db->prepare("SELECT id FROM users WHERE email = :email AND id != :id LIMIT 1");
        $check->execute(['email' => $email, 'id' => $id]);
        if ($check->fetch()) {
            $_SESSION['error'] = "Email \"{$email}\" is already used by another account.";
            header("Location: /admin/users");
            exit;
        }

        $sql = "
            UPDATE users SET
                name             = :name,
                nickname         = :nickname,
                religion         = :religion,
                email            = :email,
                role             = :role,
                department_id    = :dept,
                job_title_id     = :job,
                hod_id           = :hod,
                gm_id            = :gm,
                join_date        = :join,
                work_schedule_id = :schedule
        ";

        $params = [
            'name'     => trim($_POST['name']),
            'nickname' => trim($_POST['nickname'] ?? '') ?: null,
            'religion' => trim($_POST['religion']  ?? '') ?: null,
            'email'    => $email,
            'role'     => $_POST['role'],
            'dept'     => $_POST['department_id']    ?: null,
            'job'      => $_POST['job_title_id']     ?: null,
            'hod'      => $_POST['hod_id']           ?: null,
            'gm'       => $_POST['gm_id']            ?: null,
            'join'     => $_POST['join_date'],
            'schedule' => $_POST['work_schedule_id'] ?: null,
            'id'       => $id,
        ];

        // Only update password if provided
        if (!empty($_POST['password'])) {
            $sql .= ", password_hash = :pass";
            $params['pass'] = password_hash($_POST['password'], PASSWORD_DEFAULT);
        }

        $sql .= " WHERE id = :id";

        $stmt = $db->prepare($sql);
        $stmt->execute($params);

        $_SESSION['success'] = "User updated.";
        header("Location: /admin/users");
        exit;
    }

    public static function exportUsers()
    {
        self::authorizeAdmin();
        $db = Database::connect();

        // Reuse same filters as users() so export matches what admin sees
        $search       = trim($_GET['search'] ?? '');
        $roleFilter   = $_GET['role']   ?? '';
        $deptFilter   = $_GET['dept']   ?? '';
        $statusFilter = $_GET['status'] ?? '';

        $query = "
            SELECT
                u.name,
                u.nickname,
                u.email,
                u.religion,
                u.role,
                d.name  AS department,
                j.name  AS job_title,
                u.join_date,
                u.is_active
            FROM users u
            LEFT JOIN departments d ON u.department_id = d.id
            LEFT JOIN job_titles  j ON u.job_title_id  = j.id
            WHERE 1=1
        ";

        $params = [];

        if ($search) {
            $query .= " AND (u.name LIKE :search OR u.email LIKE :search2)";
            $params['search']  = "%$search%";
            $params['search2'] = "%$search%";
        }
        if ($roleFilter) {
            $query .= " AND u.role = :role";
            $params['role'] = $roleFilter;
        }
        if ($deptFilter) {
            $query .= " AND u.department_id = :dept";
            $params['dept'] = $deptFilter;
        }
        if ($statusFilter === 'active') {
            $query .= " AND u.is_active = 1";
        } elseif ($statusFilter === 'suspended') {
            $query .= " AND u.is_active = 0";
        }

        $query .= " ORDER BY u.name ASC";

        $stmt = $db->prepare($query);
        $stmt->execute($params);
        $users = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Output CSV
        $filename = 'users_export_' . date('Ymd_His') . '.csv';

        header('Content-Type: text/csv; charset=UTF-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Cache-Control: no-cache, no-store, must-revalidate');

        $out = fopen('php://output', 'w');

        // BOM for Excel UTF-8 compatibility
        fprintf($out, chr(0xEF) . chr(0xBB) . chr(0xBF));

        // Header row
        fputcsv($out, [
            'Full Name',
            'Nickname',
            'Email',
            'Religion',
            'Role',
            'Department',
            'Job Title',
            'Join Date',
            'Status',
        ]);

        // Data rows
        foreach ($users as $u) {
            fputcsv($out, [
                $u['name'],
                $u['nickname']   ?? '',
                $u['email'],
                $u['religion']   ?? '',
                $u['role'] === 'admin_approver' ? 'Admin' : 'Employee',
                $u['department'] ?? '',
                $u['job_title']  ?? '',
                $u['join_date']  ?? '',
                $u['is_active']  ? 'Active' : 'Suspended',
            ]);
        }

        fclose($out);
        exit;
    }

    public static function adminResetPassword()
    {
        self::authorizeAdmin();
        $db = Database::connect();

        $userId   = (int)($_POST['user_id']   ?? 0);
        $password = $_POST['password']         ?? '';

        if (!$userId || strlen($password) < 8) {
            $_SESSION['error'] = "Invalid request. Password must be at least 8 characters.";
            header("Location: /admin/users");
            exit;
        }

        // Safety: cannot reset your own password via this route
        if ($userId === (int)$_SESSION['user']['id']) {
            $_SESSION['error'] = "Use the profile page to change your own password.";
            header("Location: /admin/users");
            exit;
        }

        $stmt = $db->prepare("
            UPDATE users SET password_hash = :hash WHERE id = :id
        ");
        $stmt->execute([
            'hash' => password_hash($password, PASSWORD_DEFAULT),
            'id'   => $userId,
        ]);

        // Get employee name for success message
        $nameStmt = $db->prepare("SELECT name FROM users WHERE id = :id");
        $nameStmt->execute(['id' => $userId]);
        $name = $nameStmt->fetchColumn() ?: 'User';

        $_SESSION['success'] = "Password for {$name} has been reset successfully.";
        header("Location: /admin/users");
        exit;
    }

    public static function toggleUserStatus()
    {
        self::authorizeAdmin();
        $db = Database::connect();

        $userId = (int)$_POST['user_id'];

        $stmt = $db->prepare("
            UPDATE users
            SET is_active = IF(is_active = 1, 0, 1)
            WHERE id = ?
        ");
        $stmt->execute([$userId]);

        $_SESSION['success'] = "User status updated.";
        header("Location: /admin/users");
        exit;
    }

    public static function login()
    {
        session_start();

        $db = Database::connect();

        $email = $_POST['email'] ?? '';
        $password = $_POST['password'] ?? '';

        $stmt = $db->prepare("
            SELECT *
            FROM users
            WHERE email = ?
            LIMIT 1
        ");

        $stmt->execute([$email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$user) {
            $_SESSION['error'] = "Invalid email or password.";
            header("Location: /login");
            exit;
        }

        if (!$user['is_active']) {
            $_SESSION['error'] = "Your account has been suspended. Please contact HR.";
            header("Location: /login");
            exit;
        }

        if (!password_verify($password, $user['password_hash'])) {
            $_SESSION['error'] = "Invalid email or password.";
            header("Location: /login");
            exit;
        }

        $_SESSION['user'] = [
            'id'        => $user['id'],
            'name'      => $user['name'],
            'nickname'  => $user['nickname'] ?? null,
            'role'      => $user['role'],
            'is_active' => $user['is_active']
        ];

        header("Location: /dashboard");
        exit;
    }


    public static function logout()
    {
        session_start();
        session_destroy();

        header("Location: /login");
        exit;
    }


    public static function dashboard()
    {
        session_start();

        if (!isset($_SESSION['user'])) {
            header("Location: /login");
            exit;
        }

        require __DIR__ . '/../../resources/views/dashboard.php';
    }

    /* ==========================================================
   ADMIN – LEAVE PERIODS
    ========================================================== */

    /* ==========================================================
       ADMIN – LEAVE PERIODS
    ========================================================== */

    public static function periods()
    {
        self::authorizeAdmin();
        $db = Database::connect();

        $today = date('Y-m-d');

        $periods = $db->query("
            SELECT
                p.*,
                (SELECT COUNT(*) FROM leave_balances lb WHERE lb.leave_period_id = p.id) AS total_generated,
                (SELECT COUNT(*) FROM users WHERE role = 'employee' AND is_active = 1)   AS total_employees,
                CASE
                    WHEN p.start_date > '{$today}'                              THEN 'upcoming'
                    WHEN p.start_date <= '{$today}' AND p.end_date >= '{$today}' THEN 'active'
                    ELSE 'expired'
                END AS status
            FROM leave_periods p
            ORDER BY start_date DESC
        ")->fetchAll(PDO::FETCH_ASSOC);

        require __DIR__ . '/../../resources/views/admin_periods.php';
    }

    public static function storePeriod()
    {
        self::authorizeAdmin();
        $db = Database::connect();

        $name  = trim($_POST['name']  ?? '');
        $start = $_POST['start_date'] ?? '';
        $end   = $_POST['end_date']   ?? '';

        if (!$name || !$start || !$end) {
            $_SESSION['error'] = "All fields are required.";
            header("Location: /admin/periods");
            exit;
        }

        if ($start >= $end) {
            $_SESSION['error'] = "End date must be after start date.";
            header("Location: /admin/periods");
            exit;
        }

        $dup = $db->prepare("SELECT id FROM leave_periods WHERE name = :name LIMIT 1");
        $dup->execute(['name' => $name]);
        if ($dup->fetch()) {
            $_SESSION['error'] = "A period named \"{$name}\" already exists.";
            header("Location: /admin/periods");
            exit;
        }

        // Detect overlap — warn but don't block (SOP: 15-month periods overlap by design)
        $overlap = $db->prepare("
            SELECT name FROM leave_periods
            WHERE start_date <= :end AND end_date >= :start
        ");
        $overlap->execute(['start' => $start, 'end' => $end]);
        $overlapping = $overlap->fetchAll(PDO::FETCH_COLUMN);

        try {
            $db->prepare("
                INSERT INTO leave_periods (name, start_date, end_date)
                VALUES (:name, :start, :end)
            ")->execute(['name' => $name, 'start' => $start, 'end' => $end]);

            if (!empty($overlapping)) {
                $_SESSION['warning'] = "Period \"{$name}\" created. Overlaps with: "
                    . implode(', ', array_map('htmlspecialchars', $overlapping))
                    . " — expected for 15-month periods.";
            } else {
                $_SESSION['success'] = "Period \"{$name}\" created.";
            }
        } catch (PDOException $e) {
            $_SESSION['error'] = $e->getMessage();
        }

        header("Location: /admin/periods");
        exit;
    }

    public static function deletePeriod(int $id)
    {
        self::authorizeAdmin();
        $db = Database::connect();

        $check = $db->prepare("SELECT COUNT(*) FROM leave_balances WHERE leave_period_id = :id");
        $check->execute(['id' => $id]);
        if ((int)$check->fetchColumn() > 0) {
            $_SESSION['error'] = "Cannot delete — leave balances have been generated for this period.";
            header("Location: /admin/periods");
            exit;
        }

        $check2 = $db->prepare("SELECT COUNT(*) FROM leave_requests WHERE leave_period_id = :id");
        $check2->execute(['id' => $id]);
        if ((int)$check2->fetchColumn() > 0) {
            $_SESSION['error'] = "Cannot delete — leave requests exist under this period.";
            header("Location: /admin/periods");
            exit;
        }

        $db->prepare("DELETE FROM leave_periods WHERE id = :id")->execute(['id' => $id]);
        $_SESSION['success'] = "Period deleted.";
        header("Location: /admin/periods");
        exit;
    }

    public static function generateBalances()
    {
        self::authorizeAdmin();
        $db = Database::connect();

        $periodId = (int)$_POST['period_id'];

        try {
            $db->beginTransaction();

            $stmt = $db->prepare("SELECT * FROM leave_periods WHERE id = :id");
            $stmt->execute(['id' => $periodId]);
            $period = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$period) throw new Exception("Leave period not found.");

            $leaveTypes = $db->query("
                SELECT * FROM leave_types
                WHERE balance_source = 'period'
                AND default_days > 0
            ")->fetchAll(PDO::FETCH_ASSOC);

            if (empty($leaveTypes))
                throw new Exception("No leave types with balance_source='period' and default_days > 0. Configure leave types first.");

            $employees = $db->query("SELECT * FROM users WHERE role = 'employee' AND is_active = 1")
                ->fetchAll(PDO::FETCH_ASSOC);

            $generatedCount = 0;
            $skippedCount   = 0;
            $probationCount = 0;

            $insert = $db->prepare("
                INSERT INTO leave_balances
                (employee_id, leave_period_id, leave_type_id, total_days, remaining_days, used_days)
                VALUES (:emp, :period, :type, :days, :days, 0)
            ");

            $checkExist = $db->prepare("
                SELECT id FROM leave_balances
                WHERE employee_id = :emp AND leave_period_id = :period AND leave_type_id = :type
            ");

            foreach ($employees as $emp) {
                // Skip employees still in probation at period start date
                if (
                    !empty($emp['probation_end_date'])
                    && $emp['probation_end_date'] > $period['start_date']
                ) {
                    $probationCount++;
                    continue;
                }

                foreach ($leaveTypes as $type) {
                    $checkExist->execute([
                        'emp'    => $emp['id'],
                        'period' => $periodId,
                        'type'   => $type['id'],
                    ]);

                    if ($checkExist->fetch()) {
                        $skippedCount++;
                        continue;
                    }

                    $insert->execute([
                        'emp'    => $emp['id'],
                        'period' => $periodId,
                        'type'   => $type['id'],
                        'days'   => $type['default_days'],
                    ]);
                    $generatedCount++;
                }
            }

            $db->commit();

            $msg = "{$generatedCount} balance(s) generated.";
            if ($skippedCount   > 0) $msg .= " {$skippedCount} already existed — skipped.";
            if ($probationCount > 0) $msg .= " {$probationCount} employee(s) on probation — skipped.";

            $_SESSION['success'] = $generatedCount > 0 ? $msg : "All balances already exist for this period.";
        } catch (Exception $e) {
            $db->rollBack();
            $_SESSION['error'] = $e->getMessage();
        }

        header("Location: /admin/periods");
        exit;
    }

    /* ==========================================================
       ADMIN – LEAVE TYPES
    ========================================================== */

    public static function leaveTypes()
    {
        self::authorizeAdmin();
        $db = Database::connect();

        $leaveTypes = $db->query("
            SELECT lt.*,
                (SELECT COUNT(DISTINCT lb.employee_id)
                 FROM leave_balances lb
                 WHERE lb.leave_type_id = lt.id) AS employee_count
            FROM leave_types lt
            ORDER BY lt.name ASC
        ")->fetchAll(PDO::FETCH_ASSOC);

        require __DIR__ . '/../../resources/views/admin_leave_types.php';
    }

    public static function storeLeaveType()
    {
        self::authorizeAdmin();
        $db = Database::connect();

        $name   = trim($_POST['name']          ?? '');
        $days   = (int)($_POST['default_days'] ?? 0);
        $source = $_POST['balance_source']     ?? 'period';

        $validSources = ['period', 'comp', 'unlimited', 'admin_grant'];
        if (!in_array($source, $validSources)) $source = 'period';

        if (!$name) {
            $_SESSION['error'] = "Leave type name is required.";
            header("Location: /admin/leave-types");
            exit;
        }

        $dup = $db->prepare("SELECT id FROM leave_types WHERE name = :name LIMIT 1");
        $dup->execute(['name' => $name]);
        if ($dup->fetch()) {
            $_SESSION['error'] = "A leave type named \"{$name}\" already exists.";
            header("Location: /admin/leave-types");
            exit;
        }

        // unlimited and admin_grant don't use default_days — force to 0
        if (in_array($source, ['unlimited', 'admin_grant', 'comp'])) $days = 0;

        $db->prepare("INSERT INTO leave_types (name, default_days, balance_source) VALUES (:name, :days, :source)")
            ->execute(['name' => $name, 'days' => $days, 'source' => $source]);

        $_SESSION['success'] = "Leave type \"{$name}\" added.";
        header("Location: /admin/leave-types");
        exit;
    }

    public static function updateLeaveType(int $id)
    {
        self::authorizeAdmin();
        $db = Database::connect();

        $name = trim($_POST['name']         ?? '');
        $days = (int)($_POST['default_days'] ?? 0);

        if (!$name) {
            $_SESSION['error'] = "Leave type name is required.";
            header("Location: /admin/leave-types");
            exit;
        }

        $dup = $db->prepare("SELECT id FROM leave_types WHERE name = :name AND id != :id LIMIT 1");
        $dup->execute(['name' => $name, 'id' => $id]);
        if ($dup->fetch()) {
            $_SESSION['error'] = "Another leave type named \"{$name}\" already exists.";
            header("Location: /admin/leave-types");
            exit;
        }

        $db->prepare("UPDATE leave_types SET name = :name, default_days = :days WHERE id = :id")
            ->execute(['name' => $name, 'days' => $days, 'id' => $id]);

        $_SESSION['success'] = "Leave type updated.";
        header("Location: /admin/leave-types");
        exit;
    }

    public static function deleteLeaveType($id)
    {
        self::authorizeAdmin();
        $db = Database::connect();

        $check = $db->prepare("SELECT COUNT(*) FROM leave_balances WHERE leave_type_id = :id");
        $check->execute(['id' => $id]);
        if ((int)$check->fetchColumn() > 0) {
            $_SESSION['error'] = "Cannot delete — existing leave balances use this type.";
            header("Location: /admin/leave-types");
            exit;
        }

        $db->prepare("DELETE FROM leave_types WHERE id = :id")->execute(['id' => $id]);
        $_SESSION['success'] = "Leave type deleted.";
        header("Location: /admin/leave-types");
        exit;
    }

    /* ==========================================================
       ADMIN – BALANCES
    ========================================================== */

    public static function balances()
    {
        self::authorizeAdmin();
        $db = Database::connect();

        $search = $_GET['search'] ?? '';
        $type   = $_GET['type']   ?? '';
        $period = $_GET['period'] ?? '';
        $source = $_GET['source'] ?? ''; // NEW: period|comp|admin_grant|unlimited

        // ── Active period IDs for default filter ───────────────────────
        $activePeriods = $db->query("
            SELECT id FROM leave_periods
            WHERE start_date <= CURDATE() AND end_date >= CURDATE()
        ")->fetchAll(PDO::FETCH_COLUMN);

        $rows = [];

        // ────────────────────────────────────────────────────────────────
        // 1. PERIOD leaves — from leave_balances JOIN leave_periods
        // ────────────────────────────────────────────────────────────────
        if (!$source || $source === 'period') {
            $q1 = "
                SELECT
                    u.id     AS employee_id,
                    u.name   AS employee_name,
                    lt.id    AS leave_type_id,
                    lt.name  AS leave_type,
                    lt.balance_source,
                    lp.id    AS period_id,
                    lp.name  AS period_name,
                    lp.start_date AS period_start,
                    lp.end_date   AS period_end,
                    lb.id         AS balance_id,
                    lb.total_days,
                    lb.used_days,
                    lb.remaining_days
                FROM leave_balances lb
                JOIN users       u  ON lb.employee_id    = u.id
                JOIN leave_types lt ON lb.leave_type_id  = lt.id
                JOIN leave_periods lp ON lb.leave_period_id = lp.id
                WHERE lt.balance_source = 'period'
                  AND u.is_active = 1
            ";
            $p1 = [];
            if ($search) {
                $q1 .= " AND u.name LIKE :search";
                $p1['search'] = "%{$search}%";
            }
            if ($type) {
                $q1 .= " AND lt.id = :type";
                $p1['type']   = $type;
            }
            if ($period) {
                $q1 .= " AND lp.id = :period";
                $p1['period'] = $period;
            } elseif (!empty($activePeriods) && !$search && !$type) {
                $in = implode(',', array_map('intval', $activePeriods));
                $q1 .= " AND lp.id IN ({$in})";
            }
            $q1 .= " ORDER BY u.name ASC, lp.start_date ASC";
            $stmt = $db->prepare($q1);
            $stmt->execute($p1);
            foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $r) $rows[] = $r;
        }

        // Skip non-period sources if period filter is active
        $skipFloating = !empty($period);

        if (!$skipFloating) {

            // ──────────────────────────────────────────────────────────
            // 2. COMP leaves — aggregate from comp_claims
            // ──────────────────────────────────────────────────────────
            if ((!$source || $source === 'comp') && (!$type || self::leaveTypeSource($db, $type) === 'comp')) {
                $q2 = "
                    SELECT
                        u.id    AS employee_id,
                        u.name  AS employee_name,
                        lt.id   AS leave_type_id,
                        lt.name AS leave_type,
                        'comp'  AS balance_source,
                        NULL    AS period_id,
                        NULL    AS period_name,
                        NULL    AS period_start,
                        NULL    AS period_end,
                        NULL    AS balance_id,
                        COALESCE(SUM(CASE WHEN cc.status='approved' AND cc.expires_at > CURDATE()
                                         THEN cc.days_earned ELSE 0 END), 0) AS total_days,
                        COALESCE(SUM(CASE WHEN cc.status='approved'
                                         THEN cc.days_earned - cc.days_remaining ELSE 0 END), 0) AS used_days,
                        COALESCE(SUM(CASE WHEN cc.status='approved' AND cc.expires_at > CURDATE()
                                         THEN cc.days_remaining ELSE 0 END), 0) AS remaining_days
                    FROM users u
                    CROSS JOIN leave_types lt
                    LEFT JOIN comp_claims cc ON cc.employee_id = u.id
                    WHERE lt.balance_source = 'comp'
                      AND u.role = 'employee' AND u.is_active = 1
                ";
                $p2 = [];
                if ($search) {
                    $q2 .= " AND u.name LIKE :search";
                    $p2['search'] = "%{$search}%";
                }
                if ($type) {
                    $q2 .= " AND lt.id = :type";
                    $p2['type']   = $type;
                }
                $q2 .= "
                    GROUP BY u.id, u.name, lt.id, lt.name
                    HAVING remaining_days > 0 OR used_days > 0
                ";
                $stmt = $db->prepare($q2);
                $stmt->execute($p2);
                foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $r) $rows[] = $r;
            }

            // ──────────────────────────────────────────────────────────
            // 3. ADMIN GRANT — from leave_balances WHERE period IS NULL
            // ──────────────────────────────────────────────────────────
            if ((!$source || $source === 'admin_grant') && (!$type || self::leaveTypeSource($db, $type) === 'admin_grant')) {
                $q3 = "
                    SELECT
                        u.id    AS employee_id,
                        u.name  AS employee_name,
                        lt.id   AS leave_type_id,
                        lt.name AS leave_type,
                        'admin_grant' AS balance_source,
                        NULL    AS period_id,
                        NULL    AS period_name,
                        NULL    AS period_start,
                        NULL    AS period_end,
                        lb.id   AS balance_id,
                        lb.total_days,
                        lb.used_days,
                        (lb.total_days - lb.used_days) AS remaining_days
                    FROM leave_balances lb
                    JOIN users       u  ON lb.employee_id   = u.id
                    JOIN leave_types lt ON lb.leave_type_id = lt.id
                    WHERE lt.balance_source   = 'admin_grant'
                      AND lb.leave_period_id  IS NULL
                      AND u.is_active = 1
                      AND (lb.remaining_days > 0 OR lb.used_days > 0)
                ";
                $p3 = [];
                if ($search) {
                    $q3 .= " AND u.name LIKE :search";
                    $p3['search'] = "%{$search}%";
                }
                if ($type) {
                    $q3 .= " AND lt.id = :type";
                    $p3['type']   = $type;
                }
                $q3 .= " ORDER BY u.name ASC, lt.name ASC";
                $stmt = $db->prepare($q3);
                $stmt->execute($p3);
                foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $r) $rows[] = $r;
            }

            // ──────────────────────────────────────────────────────────
            // 4. UNLIMITED (Sick) — usage from leave_requests
            // ──────────────────────────────────────────────────────────
            if ((!$source || $source === 'unlimited') && (!$type || self::leaveTypeSource($db, $type) === 'unlimited')) {
                $q4 = "
                    SELECT
                        u.id    AS employee_id,
                        u.name  AS employee_name,
                        lt.id   AS leave_type_id,
                        lt.name AS leave_type,
                        'unlimited' AS balance_source,
                        NULL    AS period_id,
                        NULL    AS period_name,
                        NULL    AS period_start,
                        NULL    AS period_end,
                        NULL    AS balance_id,
                        NULL    AS total_days,
                        COALESCE(SUM(lr.total_days), 0) AS used_days,
                        NULL    AS remaining_days
                    FROM users u
                    CROSS JOIN leave_types lt
                    LEFT JOIN leave_requests lr
                        ON lr.employee_id    = u.id
                        AND lr.leave_type_id = lt.id
                        AND lr.status        = 'approved'
                    WHERE lt.balance_source = 'unlimited'
                      AND u.role = 'employee' AND u.is_active = 1
                ";
                $p4 = [];
                if ($search) {
                    $q4 .= " AND u.name LIKE :search";
                    $p4['search'] = "%{$search}%";
                }
                if ($type) {
                    $q4 .= " AND lt.id = :type";
                    $p4['type']   = $type;
                }
                $q4 .= "
                    GROUP BY u.id, u.name, lt.id, lt.name
                    HAVING used_days > 0
                ";
                $stmt = $db->prepare($q4);
                $stmt->execute($p4);
                foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $r) $rows[] = $r;
            }
        }

        // Sort merged rows by employee name then leave type
        usort(
            $rows,
            fn($a, $b) =>
            strcmp($a['employee_name'], $b['employee_name']) ?: strcmp($a['leave_type'], $b['leave_type'])
        );

        $balances = $rows;

        $leaveTypes = $db->query("SELECT id, name, balance_source FROM leave_types ORDER BY name ASC")
            ->fetchAll(PDO::FETCH_ASSOC);
        $periods    = $db->query("SELECT id, name, start_date, end_date FROM leave_periods ORDER BY start_date DESC")
            ->fetchAll(PDO::FETCH_ASSOC);

        require __DIR__ . '/../../resources/views/admin_balances.php';
    }


    /** Helper: get balance_source for a given leave type id */
    private static function leaveTypeSource($db, $typeId): string
    {
        static $cache = [];
        if (!isset($cache[$typeId])) {
            $s = $db->prepare("SELECT balance_source FROM leave_types WHERE id = :id");
            $s->execute(['id' => $typeId]);
            $cache[$typeId] = (string)($s->fetchColumn() ?: 'period');
        }
        return $cache[$typeId];
    }

    public static function exportBalances()
    {
        self::authorizeAdmin();
        $db = Database::connect();

        $search = $_GET['search'] ?? '';
        $type   = $_GET['type']   ?? '';
        $period = $_GET['period'] ?? '';

        $query = "
            SELECT
                u.name          AS employee,
                d.name          AS department,
                lt.name         AS leave_type,
                lp.name         AS period,
                lb.total_days,
                lb.used_days,
                (lb.total_days - lb.used_days) AS remaining_days
            FROM leave_balances lb
            JOIN users u          ON lb.employee_id    = u.id
            JOIN leave_types lt   ON lb.leave_type_id  = lt.id
            JOIN leave_periods lp ON lb.leave_period_id = lp.id
            LEFT JOIN departments d ON u.department_id  = d.id
            WHERE 1=1
        ";

        $params = [];

        if ($search) {
            $query .= " AND u.name LIKE :search";
            $params['search'] = "%$search%";
        }
        if ($type) {
            $query .= " AND lt.id = :type";
            $params['type'] = $type;
        }
        if ($period) {
            $query .= " AND lp.id = :period";
            $params['period'] = $period;
        }

        $query .= " ORDER BY u.name ASC, lt.name ASC";

        $stmt = $db->prepare($query);
        $stmt->execute($params);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $filename = 'leave_balances_' . date('Y-m-d') . '.csv';
        header('Content-Type: text/csv; charset=UTF-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Pragma: no-cache');
        header('Expires: 0');

        $out = fopen('php://output', 'w');
        fputs($out, "\xEF\xBB\xBF"); // UTF-8 BOM for Excel

        fputcsv($out, [
            'Employee',
            'Department',
            'Leave Type',
            'Period',
            'Total Days',
            'Used Days',
            'Remaining Days',
        ]);

        foreach ($rows as $r) {
            fputcsv($out, [
                $r['employee'],
                $r['department']   ?? '',
                $r['leave_type'],
                $r['period'],
                $r['total_days'],
                $r['used_days'],
                $r['remaining_days'],
            ]);
        }

        fclose($out);
        exit;
    }

    public static function adjustBalance()
    {
        self::authorizeAdmin();
        $db = Database::connect();

        $balanceId = (int)($_POST['balance_id'] ?? 0);
        $days      = (int)($_POST['days']       ?? 0);
        $reason    = trim($_POST['reason']      ?? '');

        if ($days === 0) {
            $_SESSION['error'] = "Adjustment cannot be 0.";
            header("Location: /admin/balances");
            exit;
        }

        $db->beginTransaction();
        try {
            $stmt = $db->prepare("SELECT * FROM leave_balances WHERE id = :id FOR UPDATE");
            $stmt->execute(['id' => $balanceId]);
            $balance = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$balance) throw new Exception("Balance record not found.");

            $mode = $_POST['mode'] ?? 'add';

            if ($mode === 'set') {
                // Set total quota — recalculate remaining as newTotal - used
                $newTotal = max(0, $days); // days field holds the new quota value
                $newRemaining = $newTotal - (int)$balance['used_days'];
                if ($newRemaining < 0) $newRemaining = 0;

                $db->prepare("
                    UPDATE leave_balances
                    SET total_days     = :total,
                        remaining_days = :remaining
                    WHERE id = :id
                ")->execute([
                    'total'     => $newTotal,
                    'remaining' => $newRemaining,
                    'id'        => $balanceId,
                ]);
            } else {
                // Add or deduct — only touch remaining_days
                if ($days < 0 && ($balance['remaining_days'] + $days) < 0) {
                    throw new Exception("Cannot reduce — remaining days would go below 0.");
                }

                $db->prepare("
                    UPDATE leave_balances
                    SET remaining_days = remaining_days + :days
                    WHERE id = :id
                ")->execute(['days' => $days, 'id' => $balanceId]);
            }

            $db->prepare("
                INSERT INTO leave_balance_adjustments
                (employee_id, leave_type_id, days_adjusted, reason, created_by)
                VALUES (:emp, :type, :days, :reason, :admin)
            ")->execute([
                'emp'    => $balance['employee_id'],
                'type'   => $balance['leave_type_id'],
                'days'   => $days,
                'reason' => $reason,
                'admin'  => $_SESSION['user']['id'],
            ]);

            $db->commit();
            if ($mode === 'set') {
                $_SESSION['success'] = "Quota updated to {$days} day(s). Remaining recalculated.";
            } else {
                $_SESSION['success'] = "Balance adjusted by " . ($days > 0 ? "+{$days}" : $days) . " day(s).";
            }
        } catch (Exception $e) {
            $db->rollBack();
            $_SESSION['error'] = $e->getMessage();
        }

        $qs = http_build_query(array_filter([
            'period' => $_POST['period_filter'] ?? '',
            'type'   => $_POST['type_filter']   ?? '',
            'search' => $_POST['search_filter']  ?? '',
        ]));
        header("Location: /admin/balances" . ($qs ? "?{$qs}" : ""));
        exit;
    }

    /* Recalculate remaining_days = total_days - used_days for all balances */
    public static function syncBalances()
    {
        self::authorizeAdmin();
        $db = Database::connect();

        try {
            $stmt = $db->query("
                UPDATE leave_balances
                SET remaining_days = GREATEST(0, total_days - used_days)
            ");
            $affected = $stmt->rowCount();
            $_SESSION['success'] = "Balance sync complete — {$affected} record(s) recalculated.";
        } catch (Exception $e) {
            $_SESSION['error'] = "Sync failed: " . $e->getMessage();
        }

        header("Location: /admin/balances");
        exit;
    }

    public static function balanceHistory()
    {
        self::authorizeAdmin();
        $db = Database::connect();

        $balanceId = (int)($_GET['balance_id'] ?? 0);

        // Get employee_id + leave_type_id from balance record
        $lb = $db->prepare("SELECT employee_id, leave_type_id FROM leave_balances WHERE id = :id");
        $lb->execute(['id' => $balanceId]);
        $row = $lb->fetch(PDO::FETCH_ASSOC);

        $history = [];
        if ($row) {
            $stmt = $db->prepare("
                SELECT a.days_adjusted, a.reason, a.created_at, u.name AS admin_name
                FROM leave_balance_adjustments a
                JOIN users u ON a.created_by = u.id
                WHERE a.employee_id  = :emp
                AND   a.leave_type_id = :type
                ORDER BY a.created_at DESC
            ");
            $stmt->execute(['emp' => $row['employee_id'], 'type' => $row['leave_type_id']]);
            $history = $stmt->fetchAll(PDO::FETCH_ASSOC);
        }

        header('Content-Type: application/json');
        echo json_encode($history);
        exit;
    }

    /** AJAX — available balances for employee when submitting leave */
    public static function availableBalances()
    {
        self::authorizeLogin();
        $db = Database::connect();

        $empId       = (int)$_SESSION['user']['id'];
        $leaveTypeId = (int)($_GET['leave_type_id'] ?? 0);
        $startDate   = $_GET['start_date'] ?? date('Y-m-d');
        $endDate     = $_GET['end_date']   ?? $startDate;

        $stmt = $db->prepare("
            SELECT
                lb.id           AS balance_id,
                lb.remaining_days,
                lb.total_days,
                lb.used_days,
                lp.id           AS period_id,
                lp.name         AS period_name,
                lp.start_date,
                lp.end_date
            FROM leave_balances lb
            JOIN leave_periods lp ON lb.leave_period_id = lp.id
            WHERE lb.employee_id   = :emp
            AND   lb.leave_type_id = :type
            AND   lb.remaining_days > 0
            AND   lp.start_date   <= :end
            AND   lp.end_date     >= :start
            ORDER BY lp.start_date ASC
        ");
        $stmt->execute([
            'emp'   => $empId,
            'type'  => $leaveTypeId,
            'start' => $startDate,
            'end'   => $endDate,
        ]);

        header('Content-Type: application/json');
        echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
        exit;
    }

    public static function holidays()
    {
        self::authorizeAdmin();
        $db = Database::connect();

        $year = (int)($_GET['year'] ?? date('Y'));

        $holidays = $db->prepare("
            SELECT * FROM holidays
            WHERE YEAR(holiday_date) = :year
            ORDER BY holiday_date ASC
        ");
        $holidays->execute(['year' => $year]);
        $holidays = $holidays->fetchAll(PDO::FETCH_ASSOC);

        // Attach religion list to each holiday
        $relStmt = $db->prepare("
            SELECT religion FROM holiday_religions WHERE holiday_id = :id
        ");
        foreach ($holidays as &$h) {
            $relStmt->execute(['id' => $h['id']]);
            $h['religions'] = $relStmt->fetchAll(PDO::FETCH_COLUMN);
        }
        unset($h);

        // Available years for filter
        $years = $db->query("
            SELECT DISTINCT YEAR(holiday_date) AS y
            FROM holidays
            ORDER BY y DESC
        ")->fetchAll(PDO::FETCH_COLUMN);

        // Make sure current year is always in list
        if (!in_array(date('Y'), $years)) {
            array_unshift($years, (int)date('Y'));
        }

        require __DIR__ . '/../../resources/views/admin_holidays.php';
    }

    public static function storeHoliday()
    {
        self::authorizeAdmin();
        $db = Database::connect();

        $date = $_POST['holiday_date'] ?? '';
        $name = trim($_POST['name'] ?? '');
        $type = $_POST['type'] ?? 'national';

        if (!$date || !$name) {
            $_SESSION['error'] = "Date and name are required.";
            header("Location: /admin/holidays");
            exit;
        }

        $stmt = $db->prepare("INSERT INTO holidays (holiday_date, name, type) VALUES (:date, :name, :type)");
        $stmt->execute(['date' => $date, 'name' => $name, 'type' => $type]);

        $newId     = (int)$db->lastInsertId();
        $religions = $_POST['religions'] ?? [];
        if (!empty($religions)) {
            $ins = $db->prepare("INSERT IGNORE INTO holiday_religions (holiday_id, religion) VALUES (:hid, :rel)");
            foreach ($religions as $rel) {
                $ins->execute(['hid' => $newId, 'rel' => $rel]);
            }
        }


        $_SESSION['success'] = "Holiday \"$name\" added.";
        header("Location: /admin/holidays?year=" . date('Y', strtotime($date)));
        exit;
    }

    public static function updateHoliday(int $id)
    {
        self::authorizeAdmin();
        $db = Database::connect();

        $date = $_POST['holiday_date'] ?? '';
        $name = trim($_POST['name'] ?? '');
        $type = $_POST['type'] ?? 'national';

        if (!$date || !$name) {
            $_SESSION['error'] = "Date and name are required.";
            header("Location: /admin/holidays");
            exit;
        }

        $stmt = $db->prepare("UPDATE holidays SET holiday_date = :date, name = :name, type = :type WHERE id = :id");
        $stmt->execute(['date' => $date, 'name' => $name, 'type' => $type, 'id' => $id]);


        $db->prepare("DELETE FROM holiday_religions WHERE holiday_id = :id")->execute(['id' => $id]);
        $religions = $_POST['religions'] ?? [];
        if (!empty($religions)) {
            $ins = $db->prepare("INSERT IGNORE INTO holiday_religions (holiday_id, religion) VALUES (:hid, :rel)");
            foreach ($religions as $rel) {
                $ins->execute(['hid' => $id, 'rel' => $rel]);
            }
        }

        $_SESSION['success'] = "Holiday updated.";
        header("Location: /admin/holidays?year=" . date('Y', strtotime($date)));
        exit;
    }

    public static function deleteHoliday($id)
    {
        self::authorizeAdmin();
        $db = Database::connect();

        // Get year before delete for redirect
        $stmt = $db->prepare("SELECT holiday_date FROM holidays WHERE id = :id");
        $stmt->execute(['id' => $id]);
        $row  = $stmt->fetch(PDO::FETCH_ASSOC);
        $year = $row ? date('Y', strtotime($row['holiday_date'])) : date('Y');

        $stmt = $db->prepare("DELETE FROM holidays WHERE id = :id");
        $stmt->execute(['id' => $id]);

        $_SESSION['success'] = "Holiday deleted.";
        header("Location: /admin/holidays?year=$year");
        exit;
    }


    public static function exportRequests()
    {
        self::authorizeAdmin();
        $db = Database::connect();

        $status  = $_GET['status']     ?? '';
        $search  = $_GET['search']     ?? '';
        $type    = $_GET['leave_type'] ?? '';
        $from    = $_GET['date_from']  ?? '';
        $to      = $_GET['date_to']    ?? '';

        $query = "
            SELECT
                u.name          AS employee,
                d.name          AS department,
                lt.name         AS leave_type,
                lr.start_date,
                lr.end_date,
                lr.total_days,
                lr.duration_type,
                lr.status,
                lr.rejection_reason,
                lr.created_at,
                lp.name         AS period,
                adm.name        AS processed_by,
                lr.approved_at  AS processed_at
            FROM leave_requests lr
            JOIN users u              ON lr.employee_id     = u.id
            JOIN leave_types lt       ON lr.leave_type_id   = lt.id
            LEFT JOIN departments d   ON u.department_id    = d.id
            LEFT JOIN leave_periods lp ON lr.leave_period_id = lp.id
            LEFT JOIN users adm       ON lr.approved_by     = adm.id
            WHERE 1=1
        ";

        $params = [];

        if ($status) {
            $query .= " AND lr.status = :status";
            $params['status'] = $status;
        }
        if ($search) {
            $query .= " AND u.name LIKE :search";
            $params['search'] = "%{$search}%";
        }
        if ($type) {
            $query .= " AND lt.id = :type";
            $params['type']   = $type;
        }
        if ($from) {
            $query .= " AND lr.start_date >= :from";
            $params['from'] = $from;
        }
        if ($to) {
            $query .= " AND lr.start_date <= :to";
            $params['to']   = $to;
        }

        $query .= " ORDER BY lr.created_at DESC";

        $stmt = $db->prepare($query);
        $stmt->execute($params);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $filename = 'leave_requests_' . date('Ymd_His') . '.csv';

        header('Content-Type: text/csv; charset=UTF-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Pragma: no-cache');
        header('Expires: 0');

        $out = fopen('php://output', 'w');
        // UTF-8 BOM for Excel compatibility
        fputs($out, "ï»¿");

        fputcsv($out, [
            'Employee',
            'Department',
            'Leave Type',
            'Start Date',
            'End Date',
            'Total Days',
            'Duration',
            'Status',
            'Rejection Reason',
            'Submitted At',
            'Period',
            'Processed By',
            'Processed At',
        ]);

        foreach ($rows as $r) {
            fputcsv($out, [
                $r['employee'],
                $r['department']   ?? '',
                $r['leave_type'],
                $r['start_date'],
                $r['end_date'],
                $r['total_days'],
                $r['duration_type'] === 'half_am' ? 'Half Day AM' : ($r['duration_type'] === 'half_pm' ? 'Half Day PM' : 'Full Day'),
                ucfirst($r['status']),
                $r['rejection_reason'] ?? '',
                $r['created_at'],
                $r['period']       ?? '',
                $r['processed_by'] ?? '',
                $r['processed_at'] ?? '',
            ]);
        }

        fclose($out);
        exit;
    }

    public static function requests()
    {
        self::authorizeAdmin();

        $db = Database::connect();

        // ── Filters from GET ──
        $status     = $_GET['status']     ?? '';
        $search     = $_GET['search']     ?? '';
        $typeFilter = $_GET['leave_type'] ?? '';
        $dateFrom   = $_GET['date_from']  ?? '';
        $dateTo     = $_GET['date_to']    ?? '';

        // ── Status counts for tabs ──
        $countStmt = $db->query("
            SELECT status, COUNT(*) AS total
            FROM leave_requests
            GROUP BY status
        ");
        $countsRaw = $countStmt->fetchAll(PDO::FETCH_ASSOC);
        $counts = ['all' => 0, 'pending' => 0, 'approved' => 0, 'rejected' => 0, 'cancelled' => 0];
        foreach ($countsRaw as $row) {
            $counts[$row['status']] = (int)$row['total'];
            $counts['all'] += (int)$row['total'];
        }

        // ── Leave types for filter dropdown ──
        $leaveTypes = $db->query("SELECT id, name FROM leave_types ORDER BY name ASC")
            ->fetchAll(PDO::FETCH_ASSOC);

        // ── Main query ──
        $query = "
            SELECT
                lr.id,
                lr.start_date,
                lr.end_date,
                lr.total_days,
                lr.duration_type,
                lr.status,
                lr.created_at,
                lr.approved_at,
                u.name       AS employee,
                u.id         AS employee_id,
                d.name       AS department,
                lt.name      AS leave_type,
                lt.id        AS leave_type_id
            FROM leave_requests lr
            JOIN users u        ON lr.employee_id   = u.id
            JOIN leave_types lt ON lr.leave_type_id = lt.id
            LEFT JOIN departments d ON u.department_id = d.id
            WHERE 1=1
        ";

        $params = [];

        if ($status) {
            $query .= " AND lr.status = :status";
            $params['status'] = $status;
        }

        if ($search) {
            $query .= " AND u.name LIKE :search";
            $params['search'] = "%$search%";
        }

        if ($typeFilter) {
            $query .= " AND lt.id = :type";
            $params['type'] = $typeFilter;
        }

        if ($dateFrom) {
            $query .= " AND lr.start_date >= :date_from";
            $params['date_from'] = $dateFrom;
        }

        if ($dateTo) {
            $query .= " AND lr.end_date <= :date_to";
            $params['date_to'] = $dateTo;
        }

        $query .= " ORDER BY lr.created_at DESC";

        $stmt = $db->prepare($query);
        $stmt->execute($params);
        $requests = $stmt->fetchAll(PDO::FETCH_ASSOC);

        require __DIR__ . '/../../resources/views/admin_requests.php';
    }

    /* ==========================================================
       ADMIN – SETTINGS
    ========================================================== */

    public static function settings()
    {
        self::authorizeAdmin();
        $db = Database::connect();

        $rows = $db->query("SELECT `key`, `value` FROM settings")
            ->fetchAll(PDO::FETCH_KEY_PAIR);
        $settings = $rows;

        require __DIR__ . '/../../resources/views/admin_settings.php';
    }

    public static function saveSettings()
    {
        self::authorizeAdmin();
        $db = Database::connect();

        $fields = [
            'mail_from_name',
            'mail_from_email',
            'hr_email',
            'smtp_host',
            'smtp_port',
            'smtp_user',
            'smtp_encryption',
        ];

        foreach ($fields as $key) {
            $value = trim($_POST[$key] ?? '');
            $stmt  = $db->prepare("
                INSERT INTO settings (`key`, `value`, `group`)
                VALUES (:k, :v, 'email')
                ON DUPLICATE KEY UPDATE `value` = :v2
            ");
            $stmt->execute(['k' => $key, 'v' => $value, 'v2' => $value]);
        }

        // Password — only update if provided
        if (!empty($_POST['smtp_pass'])) {
            $stmt = $db->prepare("
                INSERT INTO settings (`key`, `value`, `group`)
                VALUES ('smtp_pass', :v, 'email')
                ON DUPLICATE KEY UPDATE `value` = :v2
            ");
            $val = $_POST['smtp_pass'];
            $stmt->execute(['v' => $val, 'v2' => $val]);
        }

        $_SESSION['success'] = "Settings saved.";
        header("Location: /admin/settings");
        exit;
    }

    public static function testEmail()
    {
        self::authorizeAdmin();

        $email = trim($_POST['email'] ?? '');

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            header('Content-Type: application/json');
            echo json_encode(['ok' => false, 'message' => 'Invalid email address.']);
            exit;
        }

        require_once __DIR__ . '/../Services/MailService.php';
        $result = MailService::sendTest($email);

        header('Content-Type: application/json');
        echo json_encode($result);
        exit;
    }

    /* ==========================================================
       ADMIN – LEAVE GRANTS (admin_grant types)
    ========================================================== */

    public static function leaveGrants()
    {
        self::authorizeAdmin();
        $db = Database::connect();

        // Only admin_grant leave types
        $grantTypes = $db->query("
            SELECT * FROM leave_types
            WHERE balance_source = 'admin_grant'
            ORDER BY name ASC
        ")->fetchAll(PDO::FETCH_ASSOC);

        $employees = $db->query("
            SELECT id, name FROM users
            WHERE role = 'employee' AND is_active = 1
            ORDER BY name ASC
        ")->fetchAll(PDO::FETCH_ASSOC);

        // Recent grants
        $grants = $db->query("
            SELECT lb.id, lb.total_days, lb.used_days,
                   (lb.total_days - lb.used_days) AS remaining_days,
                   lb.created_at,
                   u.name  AS employee_name,
                   lt.name AS leave_type,
                   lb.grant_reason,
                   ab.name AS granted_by_name
            FROM leave_balances lb
            JOIN users       u  ON u.id  = lb.employee_id
            JOIN leave_types lt ON lt.id = lb.leave_type_id
            LEFT JOIN users  ab ON ab.id = lb.granted_by
            WHERE lt.balance_source  = 'admin_grant'
              AND lb.leave_period_id IS NULL
            ORDER BY lb.created_at DESC
            LIMIT 100
        ")->fetchAll(PDO::FETCH_ASSOC);

        require __DIR__ . '/../../resources/views/admin_leave_grants.php';
    }

    public static function storeLeaveGrant()
    {
        self::authorizeAdmin();
        $db = Database::connect();

        $employeeId  = (int)($_POST['employee_id']  ?? 0);
        $leaveTypeId = (int)($_POST['leave_type_id'] ?? 0);
        $days        = (float)($_POST['days']        ?? 0);
        $reason      = trim($_POST['reason']         ?? '');

        if (!$employeeId || !$leaveTypeId || $days <= 0) {
            $_SESSION['error'] = "All fields are required and days must be greater than 0.";
            header("Location: /admin/leave-grants");
            exit;
        }

        // Verify leave type is admin_grant
        $ltStmt = $db->prepare("SELECT balance_source FROM leave_types WHERE id = :id");
        $ltStmt->execute(['id' => $leaveTypeId]);
        $lt = $ltStmt->fetch(PDO::FETCH_ASSOC);

        if (!$lt || $lt['balance_source'] !== 'admin_grant') {
            $_SESSION['error'] = "Invalid leave type for manual grant.";
            header("Location: /admin/leave-grants");
            exit;
        }

        // Check if a grant record already exists for this emp + type (floating)
        $existing = $db->prepare("
            SELECT id, total_days, remaining_days FROM leave_balances
            WHERE employee_id    = :emp
              AND leave_type_id  = :type
              AND leave_period_id IS NULL
            LIMIT 1
        ");
        $existing->execute(['emp' => $employeeId, 'type' => $leaveTypeId]);
        $row = $existing->fetch(PDO::FETCH_ASSOC);

        if ($row) {
            // Add to existing grant
            $db->prepare("
                UPDATE leave_balances
                SET total_days     = total_days + :days,
                    remaining_days = remaining_days + :days,
                    grant_reason   = :reason,
                    granted_by     = :admin,
                    created_at     = NOW()
                WHERE id = :id
            ")->execute([
                'days'   => $days,
                'reason' => $reason ?: null,
                'admin'  => $_SESSION['user']['id'],
                'id'     => $row['id'],
            ]);
        } else {
            // Insert new grant record
            $db->prepare("
                INSERT INTO leave_balances
                (employee_id, leave_type_id, leave_period_id, total_days, remaining_days, used_days,
                 grant_reason, granted_by, created_at)
                VALUES
                (:emp, :type, NULL, :days, :days, 0, :reason, :admin, NOW())
            ")->execute([
                'emp'    => $employeeId,
                'type'   => $leaveTypeId,
                'days'   => $days,
                'reason' => $reason ?: null,
                'admin'  => $_SESSION['user']['id'],
            ]);
        }

        $_SESSION['success'] = "Leave granted successfully.";
        header("Location: /admin/leave-grants");
        exit;
    }

    public static function revokeLeaveGrant(int $id)
    {
        self::authorizeAdmin();
        $db = Database::connect();

        $db->prepare("DELETE FROM leave_balances WHERE id = :id AND leave_period_id IS NULL")
            ->execute(['id' => $id]);

        $_SESSION['success'] = "Grant removed.";
        header("Location: /admin/leave-grants");
        exit;
    }

    /* ==========================================================
       COMPENSATE LEAVE CLAIMS
    ========================================================== */

    public static function compClaim()
    {
        self::authorizeLogin();
        require __DIR__ . '/../../resources/views/comp_claim.php';
    }

    public static function storeCompClaim()
    {
        self::authorizeLogin();
        $db     = Database::connect();
        $userId = (int)$_SESSION['user']['id'];

        $workedDate = trim($_POST['worked_date'] ?? '');
        $reason     = trim($_POST['reason']      ?? '');

        if (!$workedDate || !$reason) {
            $_SESSION['error'] = "All fields are required.";
            header("Location: /comp-claim");
            exit;
        }

        // Cannot claim future dates
        if ($workedDate > date('Y-m-d')) {
            $_SESSION['error'] = "You cannot claim a future date.";
            header("Location: /comp-claim");
            exit;
        }

        try {
            $stmt = $db->prepare("
                INSERT INTO comp_claims (employee_id, worked_date, reason, days_earned, status, created_at)
                VALUES (:emp, :date, :reason, 1, 'pending', NOW())
            ");
            $stmt->execute([
                'emp'    => $userId,
                'date'   => $workedDate,
                'reason' => $reason,
            ]);

            $_SESSION['success'] = "Claim submitted for " . date('d M Y', strtotime($workedDate)) . ". Pending admin approval.";
        } catch (PDOException $e) {
            // Unique constraint violation — duplicate date
            if ($e->getCode() == 23000) {
                $_SESSION['error'] = "You have already submitted a claim for " . date('d M Y', strtotime($workedDate)) . ".";
            } else {
                $_SESSION['error'] = "Submission failed. Please try again.";
            }
        }

        header("Location: /comp-claim");
        exit;
    }

    public static function adminCompClaims()
    {
        self::authorizeAdmin();
        $db = Database::connect();

        $statusFilter = $_GET['status'] ?? 'pending';
        $search       = trim($_GET['search'] ?? '');

        $query = "
            SELECT cc.*,
                   u.name  AS employee_name,
                   ab.name AS approved_by_name
            FROM comp_claims cc
            JOIN  users u  ON u.id  = cc.employee_id
            LEFT JOIN users ab ON ab.id = cc.approved_by
            WHERE 1=1
        ";
        $params = [];

        if ($statusFilter !== '') {
            $query .= " AND cc.status = :status";
            $params['status'] = $statusFilter;
        }

        if ($search !== '') {
            $query .= " AND u.name LIKE :search";
            $params['search'] = "%$search%";
        }

        $query .= " ORDER BY cc.created_at DESC";

        $stmt = $db->prepare($query);
        $stmt->execute($params);
        $claims = $stmt->fetchAll(PDO::FETCH_ASSOC);

        require __DIR__ . '/../../resources/views/admin_comp_claims.php';
    }

    public static function approveCompClaim(int $id)
    {
        self::authorizeAdmin();
        $db = Database::connect();

        try {
            $db->beginTransaction();

            $stmt = $db->prepare("
                SELECT * FROM comp_claims WHERE id = :id AND status = 'pending'
                FOR UPDATE
            ");
            $stmt->execute(['id' => $id]);
            $claim = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$claim) {
                throw new Exception("Claim not found or already processed.");
            }

            $expiresAt = date('Y-m-d', strtotime('+6 months'));

            $stmt = $db->prepare("
                UPDATE comp_claims
                SET status         = 'approved',
                    approved_by    = :admin,
                    approved_at    = NOW(),
                    expires_at     = :expires,
                    days_remaining = days_earned
                WHERE id = :id
            ");
            $stmt->execute([
                'admin'   => $_SESSION['user']['id'],
                'expires' => $expiresAt,
                'id'      => $id,
            ]);

            $db->commit();
            $_SESSION['success'] = "Claim approved. Employee earns 1 compensate leave day (expires {$expiresAt}).";
        } catch (Exception $e) {
            $db->rollBack();
            $_SESSION['error'] = $e->getMessage();
        }

        header("Location: /admin/comp-claims");
        exit;
    }

    public static function rejectCompClaim(int $id)
    {
        self::authorizeAdmin();
        $db = Database::connect();

        $reason = trim($_POST['rejection_reason'] ?? '');

        $stmt = $db->prepare("
            UPDATE comp_claims
            SET status           = 'rejected',
                approved_by      = :admin,
                approved_at      = NOW(),
                rejection_reason = :reason
            WHERE id = :id AND status = 'pending'
        ");
        $stmt->execute([
            'admin'  => $_SESSION['user']['id'],
            'reason' => $reason ?: null,
            'id'     => $id,
        ]);

        $_SESSION['success'] = "Claim rejected.";
        header("Location: /admin/comp-claims");
        exit;
    }
}
